
//#include <stdio.h>
//#include <stdlib.h>
//#include <xc.h>
#include "mcc_generated_files/mcc.h"

#include "rn2483APP.h"
#include "tmrAPP.h"
#include "acuadori.h"
#include "I2C.h"
#include <math.h>

/* FOR OTAA ACTIVATION: DevEui, AppEui, AppKey  */
/* FOR ABP ACTIVATION: nwSKey, appSKey, devAddr */


uint8_t nwkSKey[16] = {0x7F, 0xB8, 0x0D, 0x9D, 0x46, 0x4A, 0x57, 0x3F, 0xEF, 
    0x68, 0x0E, 0x55, 0xAE, 0xC4, 0x52, 0x9A};
uint8_t appSKey[16] = {0xE0, 0x5B, 0x23, 0xA8, 0xC9, 0x9F, 0xD9, 0xE8, 0xAB, 
    0x4D, 0x2E, 0x99, 0x79, 0x0A, 0xFC, 0x9B};

uint8_t appKey[16] = {0x7f, 0xb8, 0x0d, 0x9d, 0x46, 0x4a, 0x57, 0x3f, 0xef, 
    0x68, 0x0e, 0x55, 0xae, 0xc4, 0x52, 0x9b};
uint32_t devAddr = 0x26011338;
//uint8_t nwkSKey[16] = {0x29, 0x45, 0xF6, 0x94, 0xF5, 0x09, 0x20, 0xDF, 0x47, 
//    0x28, 0xB9, 0x80, 0x7C, 0x08, 0x43, 0x13};
//uint8_t appSKey[16] = {0x0E, 0x53, 0xE5, 0x64, 0x40, 0x9D, 0x8C, 0x48, 0xED, 
//    0x95, 0xF1, 0x1C, 0x61, 0x26, 0xE9, 0x56};
//uint8_t appKey[16] = {0xF2, 0x5B, 0x43, 0xE4, 0x36, 0x94, 0xBB, 0x33, 0xBB, 
//    0x8C, 0x65, 0xFD, 0x2A, 0xE8, 0xFB, 0xF2};
//uint8_t deviceEui[8] = {0x00, 0x55, 0xEA, 0x96, 0x27, 0x13, 0x41, 0xAD};
uint8_t deviceEui[8] = {0xB9, 0x96, 0x8F, 0x87, 0x84, 0x48, 0x8C, 0x2D};
//uint8_t appEui[8] = {0x70, 0xB3, 0xD5, 0x7E, 0xD0, 0x01, 0x98, 0xAE};
uint8_t appEui[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
//uint32_t devAddr = 0x26012C5F;

uint8_t string[5]={0x00, 0x00, 0x00, 0x00, 0x00};
uint8_t stringLength = 5;


bool joined = false;

void RxData(uint8_t* pData, uint8_t dataLength, OpStatus_t status) {
}

void RxJoinResponse(bool status) {
    
    if (status == ACCEPTED){
        GPIODigitalWrite(GPIO10, 0);
        GPIODigitalWrite(GPIO11, 1);
        joined = true;
    } 
    else {
        
        joined = false;
        
        uint16_t counter;
        uint16_t length = 15;
        while (length){
            for(counter = 0; counter < 1000; counter++)
            {
                __delay_ms(1);
            }
            GPIODigitalToogle(GPIO10);
            length--;
            
        }
        //GPIODigitalWrite(GPIO11, 0);
        LORAWAN_Join(OTAA);  
    }   
}




//void main(void) {
//    // Initialize the device
//    
//    PIN_MANAGER_Initialize();
//    OSCILLATOR_Initialize();
////    SPI2_Initialize();
//    ADC_Initialize();
//    TMR3_Initialize();
//    TMR5_Initialize();
//    TMR1_Initialize();
//    INTERRUPT_Initialize();
//    EXT_INT_Initialize();
//    EUSART2_Initialize();
//    LORAWAN_PlatformInit();
//    
//    
//    
////    INTERRUPT_GlobalInterruptEnable();
////    INTERRUPT_PeripheralInterruptEnable();
//  
//    GPIOInit();   
//    
////    sinGeneration();
//
//    
//
//    GPIODigitalWrite(GPIO5, 0);
//    
//    GPIODigitalWrite(GPIO8, 1);
//    GPIODigitalWrite(GPIO4, 1);
//    // Set SDA HIGH
//    LATE |= _LATE_LE1_MASK;
//    
//    TMR1_StartTimer();
//    TMR5_StartTimer();
////    //rn2483_delayms(500);
//    TMR1_StopTimer();
//    TMR5_StopTimer();
////    //rn2483_delayms(500);
//    GPIODigitalWrite(GPIO11, 1);
//    TMR3_StartTimer();
////    while (1) {
//
//    sinGenStart();
//
//}
void main(void) {
    // Initialize the device
    SYSTEM_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable
    // the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to
    // enable the Global and Peripheral Interrupts
    // Use the following macros to:
    // Enable high priority global interrupts
    //INTERRUPT_GlobalInterruptHighEnable();
    // Enable low priority global interrupts.
    //INTERRUPT_GlobalInterruptLowEnable();
    // Disable high priority global interrupts
    //INTERRUPT_GlobalInterruptHighDisable();
    // Disable low priority global interrupts.
    //INTERRUPT_GlobalInterruptLowDisable();
    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();
    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();
    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();
    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    LORAWAN_Init(RxData, RxJoinResponse);
//    LORAWAN_SetClass(CLASS_C);
//    
    /* ABP ACTIVATION   */
    LORAWAN_SetNetworkSessionKey(nwkSKey);
//    LORAWAN_SetApplicationSessionKey(appSKey);
//    LORAWAN_SetDeviceAddress(devAddr);
    
    /* OTAA ACTIVATION  */
    LORAWAN_SetApplicationKey(appKey);
    LORAWAN_SetApplicationEui(appEui);
    LORAWAN_SetDeviceEui(deviceEui);
    
    //LORAWAN_SetJoinAcceptDelay2(6000);
    //LORAWAN_SetReceiveWindow2Parameters(869525000, 3);
    //LORAWAN_Join(OTAA);
    
    
    GPIOInit();
    
    //LORAWAN_SetTxPower(15);
    //timerReset();
//    TMR5_StopTimer();
//    TMR3_StopTimer();
//    GPIODigitalWrite(GPIO11, 1);
//    GPIODigitalWrite(GPIO8, 1);
//    GPIODigitalWrite(GPIO5, 1);
    sinGeneration();
    TMR5_StartTimer();
    timerReset();
    
    //impedenceAcquisition();
    GPIODigitalWrite(GPIO4, 1);
    GPIODigitalWrite(GPIO5, 0);
//    
    GPIODigitalWrite(GPIO8, 1);
    
    
    //INTERRUPT_GlobalInterruptDisable();
    //INTERRUPT_PeripheralInterruptDisable();
//    IPR2bits.TMR3IP = 1;
//    
//    
//    INTCONbits.GIEH = 1;
//    INTCONbits.GIEL = 1;
//    RCONbits.IPEN = 1;
//    uint8_t value = 8;
//    TMR3_StartTimer();
    //impedenceAcquisition();
    while (1) {
       
        
        //LORAWAN_Mainloop();
        sinGenStart(); 
        //rn2483_delayms(1000);
//        if (timer.sec == 30 && joined){
//            
//            acuadoriApp();                    
//            timerReset();
//        }
////        
//          sinGenStart();
//        i2c_start();
//    if(!i2c_sdaAddress(0x48, W)){
//        
//        for(uint8_t t=0; t<100; t++){
//        
//            i2c_sendData(0x0006);
//            //i2c_sendData(0x03FF);
//          
//        }
//    }
//
//    i2c_stop();
//        
          
        
    }
}

