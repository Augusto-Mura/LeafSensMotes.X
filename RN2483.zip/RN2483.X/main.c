
//#include <stdio.h>
//#include <stdlib.h>
//#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "rn2483APP.h"
#include "tmrAPP.h"






uint8_t nwkSKey[16] = {0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB,
    0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C};
uint8_t appSKey[16] = {0x3C, 0x8F, 0x26, 0x27, 0x39, 0xBF, 0xE3, 0xB7, 0xBC,
    0x08, 0x26, 0x99, 0x1A, 0xD0, 0x50, 0x4D};
uint32_t devAddr = 0x1F7F9F;

void RxData(uint8_t* pData, uint8_t dataLength, OpStatus_t status) {
}

void RxJoinResponse(bool status) {
}

void TMR3ISRClock(void);

void main(void) {
    uint16_t time = 0;
    uint8_t cnt = 0;
    uint8_t leafSensorValue = 0;
    uint8_t stringValue[10]={0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    uint8_t stringValueLength = 10;
    uint8_t error= 0;
    // Initialize the device
    SYSTEM_Initialize();
    TMR3_SetInterruptHandler(TMR3ISRClock);
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable
    // the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to
    // enable the Global and Peripheral Interrupts
    // Use the following macros to:
    // Enable high priority global interrupts
    //INTERRUPT_GlobalInterruptHighEnable();
    // Enable low priority global interrupts.
    //INTERRUPT_GlobalInterruptLowEnable();
    // Disable high priority global interrupts
    //INTERRUPT_GlobalInterruptHighDisable();
    // Disable low priority global interrupts.
    //INTERRUPT_GlobalInterruptLowDisable();
    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();
    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();
    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();
    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    LORAWAN_Init(RxData, RxJoinResponse);
    LORAWAN_SetNetworkSessionKey(nwkSKey);
    LORAWAN_SetApplicationSessionKey(appSKey);
    LORAWAN_SetDeviceAddress(devAddr);
    LORAWAN_Join(ABP);
    
    LORAWAN_SetNumberOfRetransmissions (50);
    
    GPIOInit();
    GPIODigitalWrite(GPIO11, 1);
    LORAWAN_SetTxPower(15);
    timerTick();
    
    while (1) {

        // Add your application code
        LORAWAN_Mainloop();
        // All other function calls of the user-defined
        // application must be made here
        if(time == 60000){
            GPIODigitalToogle(GPIO11);
            uint16ToString(cnt, stringValue);
            if(error == OK){
                acquisitionData(GPIO0, stringValue);
                stringValueLength = adaptString(stringValue, 10);
                //error++;
            }
            // Read leaf sensor value

            
            error = LORAWAN_Send(CNF, 200, stringValue, stringValueLength);
            //rn2483_delayms(15000);
            if(error != OK){
                time = 50000;
                GPIODigitalWrite(GPIO10, 1);
             }
            else{
                time = 0;
                GPIODigitalWrite(GPIO10, 0);
            }
        }
        
        __delay_ms(1);
        time++;
    }
}

void TMR3ISRClock(void){
    GPIODigitalToogle(GPIO6);
}